﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SD
{
    public partial class profile : System.Web.UI.Page
    {
        private DBI db = new DBI();
        protected User Usr = new User();
        FWClass fwClass = new FWClass();
        User _Usr = new User();

        string sql = string.Empty;
        string sql1 = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {            
            if (Session["SDAdmin"] == null)
            {
                Response.Redirect("~/Login.aspx", true);
            }

            if (Session["SDAdmin"] != null)
            {
                _Usr = (User)Session["SDAdmin"];
                FillInfo(); 
            }


        }

        private void FillInfo()
        {
                 
            try
            {

                lbl_Fname.Text = "Hi I am " + _Usr.FirstName;
                lbl_Lname.Text = _Usr.LastName;
                    lbl_Position.Text = "<b>Student : </b> Pursiung Msc in Cybersecurity at <b>Coventry University</b> , Coventry , United Kingdom ";
                    lbl_Email.Text = "<b>Email ID : </b>" + _Usr.Email;
                    lbl_Phone.Text = "<b>Phone Number : </b>" + _Usr.Phone;
                    lbl_Dob.Text = "<b>Date Of Birth : </b>" + _Usr.Dob;
                    //lbl_img.Text = "<img src=\"demo-image.jpg\" >";
                    string imgurl = "img/"+_Usr.UserName + ".jpg";
                    lbl_img.Text = "<img style=\"height:90vh; width:100% ; \" src=\"" + imgurl + "\" id=\"img_profile\" runat=\"server\" />";

                    //SOME DB OPERATION NEEDED IN FUTURE
                    //lbl_Fname.Text = "Hi I am " + "AROMAL";
                    //lbl_Lname.Text = "SURENDRAN";
                    //lbl_Position.Text = "<b>Student : </b> Pursiung Msc in Cybersecurity at <b>Coventry University</b> , Coventry , United Kingdom ";
                    //lbl_Email.Text = "<b>Email ID : </b>" + "aromal.surendran@gmail.com";
                    //lbl_Phone.Text = "<b>Phone Number : </b>" + "+91 8943737707";
                    //lbl_Dob.Text = "<b>Date Of Birth : </b>" + "24/01/1991";
                
            }
            finally
            {
                db.Close();
            }
           
        }

        
    }
}