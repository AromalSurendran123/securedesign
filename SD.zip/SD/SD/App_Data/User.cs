using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MySql.Data.MySqlClient;


public class User
{
    DBI db = new DBI();

    protected string user_id;
    protected string first_name;
    protected string last_name;
    protected string email;
    protected string status;
    protected string languageIDs;
    protected string languageDefaultID;
    protected string languageDefaultName;
    protected string languageSecondDefaultID;
    protected string languageSecondDefaultName;
    protected int languageCount;
    protected string accessType;
    protected string position;
    protected string phone;
    protected string dob;
    protected string username;
    

    //CAN BE ADDED IF NEEDED LATER
    //public User()
    //{
    //    getLanguageIDs();
    //    getDefaultLanguage();
    //    getDefaultSecondLanguage();
    //}

    private void getLanguageIDs()
    {
        languageIDs = string.Empty;

        languageCount = 0;

        string query = @"SELECT fld_id FROM tbl_languages WHERE fld_status=1;";

        MySqlCommand cmd = new MySqlCommand(query);
        //cmd.Parameters.AddWithValue("@AccountIDs", accountIDs);

        MySqlDataReader dr = null;

        try
        {
            dr = db.Read(cmd);

            while (dr.Read())
            {
                if (languageIDs == string.Empty)
                {
                    languageIDs = dr.GetString(0);
                }
                else
                {
                    languageIDs += dr.GetString(0);
                }

                languageCount += 1;
            }
            dr.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (!dr.IsClosed)
            {
                dr.Close();
            }
            db.Close();
        }
    }

    private void getDefaultLanguage()
    {
        string query = @"select fld_id,fld_language from tbl_languages " +
            "where fld_default=1 AND fld_status=1;";

        MySqlCommand cmd = new MySqlCommand(query);
        //cmd.Parameters.AddWithValue("@AccountIDs", accountIDs);

        MySqlDataReader dr = null;

        try
        {
            dr = db.Read(cmd);

            if (dr.Read())
            {
                languageDefaultID = dr.GetString(0);
                languageDefaultName = dr.GetString(1);
            }
            dr.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (!dr.IsClosed)
            {
                dr.Close();
            }
            db.Close();
        }
    }

    private void getDefaultSecondLanguage()
    {
        string query = @"select fld_id,fld_language from tbl_languages " +
            "where fld_default=0 AND fld_status=1;";

        MySqlCommand cmd = new MySqlCommand(query);
        //cmd.Parameters.AddWithValue("@AccountIDs", accountIDs);

        MySqlDataReader dr = null;

        try
        {
            dr = db.Read(cmd);

            if (dr.Read())
            {
                languageSecondDefaultID = dr.GetString(0);
                languageSecondDefaultName = dr.GetString(1);
            }
            dr.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (!dr.IsClosed)
            {
                dr.Close();
            }
            db.Close();
        }
    }
           
    public string UserId
    {
        get
        {
            return user_id;
        }
        set
        {
            user_id = value;
        }
    }
    
    public string AccessType
    {
        get
        {
            return accessType;
        }
        set
        {
            accessType = value;
        }
    }

    public string FirstName
    {
        get
        {
            return first_name;
        }
        set
        {
            first_name = value;
        }
    }

    public string LastName
    {
        get
        {
            return last_name;
        }
        set
        {
            last_name = value;
        }
    }

    public string Email
    {
        get
        {
            return email;
        }
        set
        {
            email = value;
        }
    }

    public string Status
    {
        get
        {
            return status;
        }
        set 
        {
            status = value;
        }
    }

    public string LanguageIDs
    {
        get
        {
            return languageIDs;
        }
        set
        {
            languageIDs = value;
        }
    }

    public string LanguageDefaultID
    {
        get
        {
            return languageDefaultID;
        }
        set
        {
            languageDefaultID = value;
        }
    }      

    public string LanguageDefaultName
    {
        get
        {
            return languageDefaultName;
        }
        set
        {
            languageDefaultName = value;
        }
    }

    public string LanguageSecondDefaultID
    {
        get
        {
            return languageSecondDefaultID;
        }
        set
        {
            languageSecondDefaultID = value;
        }
    }

    public string LanguageSecondDefaultName
    {
        get
        {
            return languageSecondDefaultName;
        }
        set
        {
            languageSecondDefaultName = value;
        }
    }

    public int LanguageCount
    {
        get
        {
            return languageCount;
        }
        set
        {
            languageCount = value;
        }
    }

    public string Position
    {
        get
        {
            return position;
        }
        set
        {
            position = value;
        }
    }

    public string Phone
    {
        get
        {
            return phone;
        }
        set
        {
            phone = value;
        }
    }

    public string Dob
    {
        get
        {
            return dob;
        }
        set
        {
            dob = value;
        }
    }

    public string UserName
    {
        get
        {
            return username;
        }
        set
        {
            username = value;
        }
    }

}

