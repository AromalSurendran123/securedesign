var submit_click=false;
if(typeof String.prototype.trim !== 'function') {
  String.prototype.trim = function() {
    return this.replace(/^\s+|\s+$/g, ''); 
  }
}
        function Init (frm) {
            var form = document.getElementById (frm);
            if ("onfocusin" in form) {  // Internet Explorer
                    // the attachEvent method can also be used in IE9,
                    // but we want to use the cross-browser addEventListener method if possible
                if (form.addEventListener) {    // IE from version 9
                    form.addEventListener ("focusout", automaticCall, false);
                }
                else {
                    if (form.attachEvent) {     // IE before version 9
                        form.attachEvent ("onfocusout", automaticCall);
                    }
                }
            }
            else {
                if (form.addEventListener) {    // Firefox, Opera, Google Chrome and Safari
                        // since Firefox does not support the DOMFocusIn/Out events
                        // and we do not want browser detection
                        // the focus and blur events are used in all browsers excluding IE
                        // capturing listeners, because focus and blur events do not bubble up
                    form.addEventListener ("blur", automaticCall, true);
                }
            }
        }
function automaticCall()
{
    if(submit_click)
    {
        validateEntries();
    }
}
function validateTxtBxs(txtbxs)
{

	var allok=true;
	for(i=0;i<txtbxs.length;i++)
	{
		if((document.getElementById(txtbxs[i]).value==null) || (document.getElementById(txtbxs[i]).value.trim()==""))
		{
		    document.getElementById(txtbxs[i]).style.backgroundColor = "#fc9e6f";
			allok=false;
		}
		else
		{
			document.getElementById(txtbxs[i]).style.backgroundColor="white";
		}
	}
	return allok;
}

function validateDateFiled(txtbxs) {//yyyy-mm-dd

    var allok = true;
    var rgx = /(\d{4})-(\d{2})-(\d{2})/;
    for (i = 0; i < txtbxs.length; i++) {        
        var s = document.getElementById(txtbxs[i]).value;
        if (!s.match(rgx)) {
            document.getElementById(txtbxs[i]).value = "";
            document.getElementById(txtbxs[i]).style.backgroundColor = "#fc9e6f";
            allok = false;
        }
        else {
            document.getElementById(txtbxs[i]).style.backgroundColor = "white";
        }
    }
    return allok;
}

function validateDDLs(ddls,uaindex)
{
	var allok=true;
	for(i=0;i<ddls.length;i++)
	{
		if(document.getElementById(ddls[i]).selectedIndex == uaindex)
		{
		    document.getElementById(ddls[i]).style.backgroundColor = "#fc9e6f";
			allok=false;
		}
		else
		{
			document.getElementById(ddls[i]).style.backgroundColor="white";
		}
	}
	return allok;
}
function validateRadioButtonList(rblName, rblId) {
    var listItemArray = document.getElementsByName(rblName);
    var isItemChecked = false;
    for (var i = 0; i < listItemArray.length; i++) {
        var listItem = document.getElementById(rblId + "_" + i);
        if(listItem!=null)
        {
			if (listItem.checked) {
				isItemChecked = true;
			}
        }
    }
    if(isItemChecked)
    {
		document.getElementById(rblId).style.backgroundColor="white";
    }
    else
    {
        document.getElementById(rblId).style.backgroundColor = "#fc9e6f";
    }
    return isItemChecked;
}
function validateEmail(txtbxs)
{
	var allok=true;
	var x;
    var atpos;
    var dotpos;
	for(i=0;i<txtbxs.length;i++)
	{
	    x = document.getElementById(txtbxs[i]).value.trim();
        atpos=x.indexOf("@");
        dotpos=x.lastIndexOf(".");
        if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
        {
            document.getElementById(txtbxs[i]).style.backgroundColor = "#fc9e6f";
			allok=false;
        }
        else
		{
			document.getElementById(txtbxs[i]).style.backgroundColor="white";
		}
	}
	return allok;
}

function validateEmailIgnoreBlank(txtbxs) {   
    var allok = true;
    var x;
    var atpos;
    var dotpos;
    for (i = 0; i < txtbxs.length; i++) {
        x = document.getElementById(txtbxs[i]).value.trim();
        document.getElementById(txtbxs[i]).style.backgroundColor = "white";
        if (x.trim() != "") {

            atpos = x.indexOf("@");
            dotpos = x.lastIndexOf(".");
            if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) {
                document.getElementById(txtbxs[i]).style.backgroundColor = "#fc9e6f";
                allok = false;
            }           
        }
    }
    return allok;
}


function validateConfirmFields(field1, field2) {
    var allok = true;
    if (document.getElementById(field1).value.trim() != document.getElementById(field2).value.trim()) {
        document.getElementById(field2).style.backgroundColor = "#fc9e6f";
        allok = false;
    } else {
        document.getElementById(field2).style.backgroundColor = "white";
    }
    return allok;
}

function ValidateImagUpload(FileUpload) {

    var allok = true;
    debugger;

    var array = ['jpg', 'jpeg', 'bmp', 'gif', 'png'];
    
    var uploader = document.getElementById(FileUpload);
    var Extension = uploader.value.trim().substring(uploader.value.lastIndexOf('.') + 1).toLowerCase();
    if (Extension != null && Extension.trim() != "") {
        if (array.indexOf(Extension) <= -1) {
            document.getElementById(FileUpload).style.backgroundColor = "#fc9e6f";
            allok = false;
        }
        else {
            document.getElementById(FileUpload).style.backgroundColor = "white";
        }
    }
    else {
        document.getElementById(FileUpload).style.backgroundColor = "white";
    }
    return allok;

}



function validateCanadaZipCode(txtbxs)
{
	var allok=true;
	var re = /^([A-Za-z]\d[A-Za-z] \d[A-Za-z]\d|[A-Za-z]\d[A-Za-z]\d[A-Za-z]\d)$/;
	for(i=0;i<txtbxs.length;i++)
	{
		if(!re.test(document.getElementById(txtbxs[i]).value))
        {
		    document.getElementById(txtbxs[i]).style.backgroundColor = "#fc9e6f";
			allok=false;
        }
        else
		{
			document.getElementById(txtbxs[i]).style.backgroundColor="white";
		}
	}
	return allok;
}
function validateUSZipCode(txtbxs)
{
	var allok=true;
	var re = /^(\d{5}-\d{4}|\d{5})$/;
	for(i=0;i<txtbxs.length;i++)
	{
		if(!re.test(document.getElementById(txtbxs[i]).value))
        {
		    document.getElementById(txtbxs[i]).style.backgroundColor = "#fc9e6f";
			allok=false;
        }
        else
		{
			document.getElementById(txtbxs[i]).style.backgroundColor="white";
		}
	}
	return allok;
}
function validatePhone(txtbxs)
{
	var allok=true;
	var re = /^[\(]?\d{3}[\s\)-]?\d{3}[\s-]?\d{4}$/;
	for(i=0;i<txtbxs.length;i++)
	{
		if(!re.test(document.getElementById(txtbxs[i]).value))
        {
		    document.getElementById(txtbxs[i]).style.backgroundColor = "#fc9e6f";
			allok=false;
        }
        else
		{
			document.getElementById(txtbxs[i]).style.backgroundColor="white";
		}
	}
	return allok;
}

//Check Number 
function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;

    return true;
}
//Check decimel Number / price
function isPriceKey(txtVal, evt) {

    var charCode = (evt.which) ? evt.which : event.keyCode

    if (txtVal.indexOf('.') == -1) {
        if (charCode != 46) {
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
        }
    }
    else {
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;
    }
    return true;
}



function IsAlphaNumeric(e) {
    var specialKeys = new Array();
    specialKeys.push(8); //Backspace
    specialKeys.push(9); //Tab
    specialKeys.push(46); //Delete
    specialKeys.push(36); //Home
    specialKeys.push(35); //End
    specialKeys.push(37); //Left
    specialKeys.push(39); //Right
    var keyCode = e.keyCode == 0 ? e.charCode : e.keyCode;
    var ret = ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 65 && keyCode <= 90) || (keyCode >= 97 && keyCode <= 122) || (specialKeys.indexOf(e.keyCode) != -1 && e.charCode != e.keyCode));
    //document.getElementById("error").style.display = ret ? "none" : "inline";
     return ret;
}

function isValidCreditCard(type, ccnum) {
    ccnum = ccnum.replace(" ").join("");
    if (type == "Visa") {
        // Visa: length 16, prefix 4, dashes optional.
        var re = /^4\d{3}-?\d{4}-?\d{4}-?\d{4}$/;
    } else if (type == "MC") {
        // Mastercard: length 16, prefix 51-55, dashes optional.
        var re = /^5[1-5]\d{2}-?\d{4}-?\d{4}-?\d{4}$/;
    } else if (type == "AmEx") {
        // American Express: length 15, prefix 34 or 37.
        var re = /^3[4,7]\d{13}$/;
    }
    if (!re.test(ccnum)) return false;
    // Remove all dashes for the checksum checks to eliminate negative numbers
    ccnum = ccnum.split("-").join("");
    // Checksum ("Mod 10")
    // Add even digits in even length strings or odd digits in odd length strings.
    var checksum = 0;
    for (var i = (2 - (ccnum.length % 2)) ; i <= ccnum.length; i += 2) {
        checksum += parseInt(ccnum.charAt(i - 1));
    }
    // Analyze odd digits in even length strings or even digits in odd length strings.
    for (var i = (ccnum.length % 2) + 1; i < ccnum.length; i += 2) {
        var digit = parseInt(ccnum.charAt(i - 1)) * 2;
        if (digit < 10) { checksum += digit; } else { checksum += (digit - 9); }
    }
    if ((checksum % 10) == 0) return true; else return false;
}

function getRadiobuttonSelectedItem(rblName, rblId) {   
    var listItemArray = document.getElementsByName(rblName);
    var isItemChecked = false;
    for (var i = 0; i < listItemArray.length; i++) {
        var listItem = document.getElementById(rblId + "_" + i);
        if (listItem != null) {
            if (listItem.checked) {
                isItemChecked = true;
                return listItem.id;
                break;

            }
        }
    }
}


/*------------Popup messages---------*/
function InfoPopup(title, msg) {
    if (title == "")
        title = "Warning";
    swal({
        title: title,
        text: msg,
        html: true,
        type: "warning"
    });

    $(".confirm").click(function () {
        if ($(".modal-backdrop").length > 1)
            $(".modal-backdrop").last().remove();
        $("body").removeAttr("style");
if(title == "Session expired"){
    url = "logout.aspx";
    $(location).attr("href", url);
}
    });
    return false;
}

function SuccessPopup(title, msg) {
    if (title == "")
        title = "Success";
    swal({
        title: title,
        text: msg,
        html: true,
        type: "success"
    });

    $(".confirm").click(function () {
        if ($(".modal-backdrop").length > 1)
            $(".modal-backdrop").last().remove();
        $("body").removeAttr("style");
    });
    return false;
}
function ErrorPopup(title, msg) {
    if (title == "")
        title = "Warning";
    swal({
        title: title,
        text: msg,
        html: true,
        type: "error"
    });
    $(".confirm").click(function () {
        if ($(".modal-backdrop").length > 1)
            $(".modal-backdrop").last().remove();
        $("body").removeAttr("style");
    });
    return false;
}

//function validateUrl(textval)   // return true or false.
//{
//    var urlregex = new RegExp(
//          "^(http:\/\/www.|https:\/\/www.|ftp:\/\/www.|www.){1}([0-9A-Za-z]+\.)");
//    return urlregex.test(textval);
//}

function validateUrl(txtbxs) {
    var allok = true;
    var re = /^(http:\/\/www.|https:\/\/www.|ftp:\/\/www.|www.){1}([0-9A-Za-z]+\.)/;
    for (i = 0; i < txtbxs.length; i++) {
        if (!re.test(document.getElementById(txtbxs[i]).value)) {
            document.getElementById(txtbxs[i]).style.backgroundColor = "#fc9e6f";
            allok = false;
        }
        else {
            document.getElementById(txtbxs[i]).style.backgroundColor = "white";
        }
    }
    return allok;
}
function SuccessConfirmPopup(title, msg, redirectpage) {
    if (title == "")
        title = "Success";
    swal({
        title: title,
        text: msg,
        html: true,
        type: "success"
    });

    $(".confirm").click(function () {
        $(location).attr("href", redirectpage);
    });
    return false;
}