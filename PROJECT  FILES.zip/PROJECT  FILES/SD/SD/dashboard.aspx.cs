﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SD
{
    public partial class dashboard : System.Web.UI.Page
    {
        private DBI db = new DBI();
        private DBI db1 = new DBI();
        private DBI db2 = new DBI();
        protected User Usr = new User();
        FWClass fwClass = new FWClass();
        User _Usr = new User();
        string sql = string.Empty;
        string sql1 = string.Empty;
        string sql2 = string.Empty;
        MySql.Data.MySqlClient.MySqlCommand cmd = null;
        MySql.Data.MySqlClient.MySqlCommand cmd1 = null;
        MySql.Data.MySqlClient.MySqlCommand cmd2 = null;
        MySqlDataReader dr = null;


        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["SDAdmin"] == null)
            {
                Response.Redirect("~/Login.aspx", true);
            }

            if (Session["SDAdmin"] != null)
            {
                _Usr = (User)Session["SDAdmin"];
                FillGrid();
                FillAircraft();
                FillEngineers();
                FillScheduleGrid();
                //FormatScheduleTable();
                //FormatAircraftTable();
            }

        }


        protected void btn_logout(object sender, EventArgs e)
        {
            Session["SDAdmin"] = null;
            Response.Redirect("index.aspx");
        }


        private void FillAircraft()
        {
            try
            {
                ddl_aircraft.Items.Clear();
                ListItem item = new ListItem();
                item = new ListItem("-- PLEASE SELECT --", "0");
                ddl_aircraft.Items.Add(item);
                sql = "SELECT fld_id , CONCAT(fld_aircraft_number,' -- ',CASE WHEN fld_aircraft_name = '1' THEN 'CESSNA 152' " +
                " WHEN fld_aircraft_name = '2' THEN 'PHOENIX' WHEN fld_aircraft_name = '3' THEN 'HERPA AIR 35'  END) as aircraft_number " +
                " FROM tbl_aircraft WHERE fld_schedule ='2' ORDER BY fld_id ;";
                MySqlCommand cmd = new MySqlCommand(sql);
                dr = db.Read(cmd);
                while (dr.Read())
                {
                    item = new ListItem(dr["aircraft_number"].ToString(), dr["fld_id"].ToString());
                    ddl_aircraft.Items.Add(item);

                }
                dr.Close();

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                db.Close();
            }
        }

        private void FillEngineers()
        {
            try
            {
                ddl_add_schedule_select_engineer.Items.Clear();
                ListItem item = new ListItem();
                item = new ListItem("-- PLEASE SELECT A ENGINEER --", "0");
                ddl_add_schedule_select_engineer.Items.Add(item);
                sql = "SELECT fld_id,  CONCAT(fld_name ,' -- ', fld_task) AS eng_category FROM tbl_engineers WHERE fld_scheduled !='1' ORDER BY fld_id ;";
                MySqlCommand cmd = new MySqlCommand(sql);
                dr = db.Read(cmd);
                while (dr.Read())
                {
                    item = new ListItem(dr["eng_category"].ToString(), dr["fld_id"].ToString());
                    ddl_add_schedule_select_engineer.Items.Add(item);

                }
                dr.Close();

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                db.Close();
            }
        }

        private void FillGrid()
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                sql = "SELECT fld_id," +
               "case fld_aircraft_name when '1' then 'CESSNA 152'  when '2' then 'PHOENIX'  when '3' then 'HERPA AIR 35' end as aircraft_name," +
               "fld_age," +
               "fld_manufacture_year," +
               "case fld_aircraft_type when '1' then 'HELICOPTTER' when '2' then 'TURBINE' when '3' then 'PISTON'" +
               "when '4' then 'CARGO' when '5' then 'PASSENGER' end as aircraft_type," +
               "fld_aircraft_number," +
               "fld_running_hours," +
               "case fld_schedule when '1' then '<font color=Green>Scheduled</font>'  when '2' then '<font color=Red>Unscheduled</font>' end as schedule," +
               "DATE_FORMAT(fld_date_added, '%M %d %Y') as fld_date_added" +
               ",fld_status " +
               "FROM tbl_aircraft where fld_status = '1' ";
                cmd = new MySqlCommand(sql);
                dr = db.Read(cmd);
                sb.Append("<table id=\"tblAircraft\" class=\"table table-striped table-bordered calwidth\" cellspacing=\"0\" >" +
                "<thead>" +
                 "<tr>" +
                    "<th>AIRCRAFT COMPANY</th>" +
                    "<th>AIRCRAFT NUMBER</th>" +
                    "<th>AGE</th>" +
                    "<th>YEAR</th>" +
                    "<th>AIRCRAFT TYPE</th>" +
                    "<th>RUNNING HOURS</th>" +
                    "<th>STATUS</th>" +
                     "<th>DATE</th>" +
                "</tr>" +
                "</thead>" +
                "<tbody>");

                bool flag = false;
                while (dr.Read())
                {
                    flag = true;
                    sb.Append("<tr>")
                    .Append("" +
                    "<td style=\"padding-left:8px;\">" + dr["aircraft_name"].ToString() + "</td>" +
                     "<td style=\"padding-left:8px;\">" + dr["fld_aircraft_number"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_age"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_manufacture_year"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["aircraft_type"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_running_hours"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["schedule"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_date_added"].ToString() + "</td>" +
                    "</tr>");
                }
                dr.Close();
                sb.Append("</tbody></table>");

                if (!flag)
                {
                    sb = new StringBuilder();
                    sb.Append("<h3 align=\"center\" class=\"text-warning\">No aircraft record found.</h3>");
                }

                lbl_AircraftGrid.Text = sb.ToString();

            }
            finally
            {
                db.Close();
            }

        }


        private void FormatAircraftTable()
        {
            string script = "FormatAircraftTable();";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "keySend1", script, true);
        }

        private void FormatScheduleTable()
        {
            string script = "FormatScheduleTable();";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "keySend1", script, true);
        }

        private void FillScheduleGrid()
        {

            StringBuilder sb = new StringBuilder();
            try
            {

                sql = "SELECT fld_id," +
               "fld_aircraft_name," +
               "case fld_task when '1' then 'A check' when '2' then 'A check' when '3' then 'A check'" +
               "when '4' then 'A check' when '5' then 'A check' end as task," +
               "fld_engineer_name," +
               "DATE_FORMAT(fld_date_scheduled, '%M %d %Y') as fld_date_scheduled " +
               "FROM tbl_schedule ";
                cmd = new MySqlCommand(sql);
                dr = db.Read(cmd);
                sb.Append("<table id=\"tblSchedule\" class=\"table table-striped table-bordered calwidth\" cellspacing=\"0\" >" +
                "<thead>" +
                 "<tr>" +
                    "<th>AIRCRAFT</th>" +
                    "<th>TASK</th>" +
                    "<th>ENGINEER</th>" +
                    "<th>DATE ASSIGNED</th>" +
                "</tr>" +
                "</thead>" +
                "<tbody>");

                bool flag = false;
                while (dr.Read())
                {
                    flag = true;
                    sb.Append("<tr>")
                    .Append("" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_aircraft_name"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["task"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_engineer_name"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_date_scheduled"].ToString() + "</td>" +
                    "</tr>");
                }
                dr.Close();
                sb.Append("</tbody></table>");

                if (!flag)
                {
                    sb = new StringBuilder();
                    sb.Append("<h3 align=\"center\" class=\"text-warning\">No sceduled record found.</h3>");
                }

                lbl_ScheduleGrid.Text = sb.ToString();

            }
            finally
            {
                db.Close();
            }

        }


        private void AleadyExist()
        {
            string msg = "This Aircraft already exist in the database";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "BQW", "javascript:InfoPopup('','" + msg + "','1');", true);

        }

        private void ShowAircraftAdd()
        {
            string script = "ShowAircratftAdd();";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "keySend1", script, true);
        }




        protected void btn_add_schedule(object sender, EventArgs e)
        {
            string _aircraft_id = string.Empty;
            string _aircraft_name = string.Empty;
            string _engineer_id = string.Empty;
            string _engineer_name = string.Empty;
            string _task = string.Empty;

            try
            {

                _aircraft_id = hid_aircraft_id.Value;
                _aircraft_name = hid_aircraft_name.Value;
                _engineer_id = hid_engineer_id.Value;
                _engineer_name = hid_engineer_name.Value;
                _task = hid_task_id.Value;


                sql = "INSERT INTO tbl_schedule(" +
                   "fld_aircraft_id," +
                   "fld_scheduled," +
                   "fld_aircraft_name," +
                   "fld_engineer_id," +
                   "fld_engineer_name," +
                   "fld_task," +
                   "fld_date_scheduled ) VALUES(" +
                   "@_aircraft_id," +
                   "@_scheduled," +
                   "@_aircraft_name," +
                   "@_engineer_id," +
                   "@_engineer_name," +
                   "@_task," +
                   "'" + DateTime.Now.ToString("yyyy-MM-dd") + "')";


                cmd = new MySqlCommand(sql);
                cmd.Parameters.AddWithValue("@_aircraft_id", _aircraft_id);
                cmd.Parameters.AddWithValue("@_aircraft_name", _aircraft_name);
                cmd.Parameters.AddWithValue("@_engineer_id", _engineer_id);
                cmd.Parameters.AddWithValue("@_engineer_name", _engineer_name);
                cmd.Parameters.AddWithValue("@_task", _task);
                cmd.Parameters.AddWithValue("@_scheduled", '1');
                db.Execute(cmd);

                sql1 = "Update tbl_aircraft set fld_schedule = @scheduled where fld_id = @_aircraft_id";
                cmd1 = new MySqlCommand(sql1);
                cmd1.Parameters.AddWithValue("@scheduled", '1');
                cmd1.Parameters.AddWithValue("@_aircraft_id", _aircraft_id);
                db1.Execute(cmd1);

                sql2 = "Update tbl_engineers set fld_scheduled = @scheduled where fld_id = @_engineer_id";
                cmd2 = new MySqlCommand(sql2);
                cmd2.Parameters.AddWithValue("@scheduled", '1');
                cmd2.Parameters.AddWithValue("@_engineer_id", _engineer_id);
                db2.Execute(cmd2);

            }
            finally
            {
                db.Close();
                db1.Close();
                db2.Close();
                Response.Redirect("dashboard.aspx");
            }
        }


        protected void btn_add_aircraft(object sender, EventArgs e)
        {
            string aircraft_number = string.Empty;
            bool isexist = false;

            aircraft_number = txt_add_aircraft_number.Text;
            sql = "select fld_aircraft_number from tbl_aircraft where fld_status ='1' and fld_aircraft_number='" + aircraft_number + "'";
            cmd = new MySqlCommand(sql);
            dr = db.Read(cmd);
            if (dr.Read())
            {
                isexist = true;
                AleadyExist();
            }
            dr.Close();


            if (isexist == false)
            {
                try
                {
                    sql = "INSERT INTO tbl_aircraft(" +
                       "fld_aircraft_name," +
                       "fld_age," +
                       "fld_manufacture_year," +
                       "fld_aircraft_type," +
                       "fld_aircraft_number," +
                       "fld_running_hours," +
                       "fld_schedule," +
                       "fld_date_added," +
                       "fld_status) VALUES(" +
                       "@_aircraft_name," +
                       "@_age," +
                       "@_manufacture_year," +
                       "@_aircraft_type," +
                       "@_aircraft_number," +
                       "@_running_hours," +
                       "@_schedule," +
                       "'" + DateTime.Now.ToString("yyyy-MM-dd") + "'," +
                       "1);SELECT max(fld_id) as aircraftid from tbl_aircraft";
                    cmd = new MySqlCommand(sql);
                    cmd.Parameters.AddWithValue("@_aircraft_name", ddl_add_aircraft_name.SelectedValue);
                    cmd.Parameters.AddWithValue("@_age", txt_add_aircraft_age.Text);
                    cmd.Parameters.AddWithValue("@_manufacture_year", txt_add_aircraft_manufacture_year.Text);
                    cmd.Parameters.AddWithValue("@_aircraft_type", ddl_add_aircraft_type.SelectedValue);
                    cmd.Parameters.AddWithValue("@_aircraft_number", txt_add_aircraft_number.Text);
                    cmd.Parameters.AddWithValue("@_running_hours", txt_add_aircraft_hours.Text);
                    //cmd.Parameters.AddWithValue("@_schedule", ddl_aircraft_scedule.SelectedValue);
                    cmd.Parameters.AddWithValue("@_schedule", '2');
                    db.Execute(cmd);

                }
                finally
                {
                    db.Close();
                    Response.Redirect("dashboard.aspx");
                }

            }
        }


        private void Chk()
        {
            string script = "check();";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "keySend1", script, true);
        }




        private void EngineerAleadyExist()
        {
            string msg = "This engineer already exist in the database";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "BQW", "javascript:InfoPopup('','" + msg + "','1');", true);

        }


        protected void btn_add_engineer(object sender, EventArgs e)
        {
            string engineername = string.Empty;
            bool isexist = false;

            engineername = txt_add_engineer.Text;

            sql = "select fld_name from tbl_engineers where fld_name='" + engineername + "'";
            cmd = new MySqlCommand(sql);
            dr = db.Read(cmd);
            if (dr.Read())
            {
                isexist = true;
                EngineerAleadyExist();
            }
            dr.Close();


            if (isexist == false)
            {
                try
                {

                    sql = "INSERT INTO tbl_engineers(" +
                       "fld_name," +
                       "fld_task," +
                       "fld_scheduled) VALUES(" +
                       "@_name," +
                       "@_task," +
                       "2);SELECT max(fld_id) as engineerid from tbl_engineers";
                    cmd = new MySqlCommand(sql);
                    cmd.Parameters.AddWithValue("@_name", engineername);
                    cmd.Parameters.AddWithValue("@_task", hid_engineer_category_value_text.Value);
                    db.Execute(cmd);

                }
                finally
                {
                    db.Close();
                    Response.Redirect("dashboard.aspx");
                    //Chk();
                }
            }
        }

    }
}