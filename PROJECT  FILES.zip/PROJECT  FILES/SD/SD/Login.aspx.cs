﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SD
{
    public partial class Login : System.Web.UI.Page
    {
        private DBI db = new DBI();
        protected User Usr = new User();
        FWClass fwClass = new FWClass();

        protected void Page_Load(object sender, EventArgs e)
        {

            this.Page.Title = "ABC AIR";
            if (!Page.IsPostBack)
            {
                Session["PAGE_LOAD"] = null;
                ScriptManager.RegisterStartupScript(this, this.GetType(), "LAW", "javascript:ClearLoginFields();", true);              
            }

            //CAN BE USED IF NEEDE LATER
            //txt_UserEmail.Attributes.Add("onkeypress", "return submitUser(event)");
            //txt_Password.Attributes.Add("onkeypress", "return submitUser(event)");
           
        }

        public bool ValidateUser(string _usr, string _pwd)
        {

            MySqlDataReader dr = null;
            bool flag = false;
            string sql = "";

            try
            {
                sql = "SELECT  fld_id," +
                    "fld_firstname," +
                    "fld_lastname," +
                    "fld_email AS email, " +
                    "fld_phone ," +
                    "DATE_FORMAT(fld_dateadded, '%M %d %Y') " +
                    ",fld_username " +
                    "FROM tbl_admin " +
                    "WHERE fld_username= @usr " +
                    "AND fld_password = @pwd " +
                    "AND fld_status = '1'";


                MySqlCommand cmd = new MySqlCommand(sql);
                cmd.Parameters.AddWithValue("@usr", _usr);
                cmd.Parameters.AddWithValue("@pwd", _pwd);
                dr = db.Read(cmd);

                if (dr.Read())
                {
                    flag = true;
                    Usr.UserId = dr.GetString(0);
                    Usr.FirstName = dr.GetString(1);
                    Usr.LastName = dr.GetString(2);
                    Usr.Email = dr.GetString(3);
                    Usr.Phone = dr.GetString(4);
                    Usr.Dob = dr.GetString(5);
                    Usr.UserName = dr.GetString(6);
                    
                }
                dr.Close();

                if (flag == true)
                {
                    System.Web.HttpContext.Current.Session["SDAdmin"] = Usr;
                    //System.Web.HttpContext.Current.Session.Timeout = 10000;
                    System.Web.Security.FormsAuthentication.SetAuthCookie(Usr.UserId, false);
                    fwClass.saveLogin(Usr.UserId, Request.UserHostAddress);
                }
            }
            finally
            {
                db.Close();
            }
            return flag;
        }

        protected void btn_login_Click(object sender, EventArgs e)
        {
            
            if (txt_UserEmail.Text != "" && txt_Password.Text != "")
            {
                string usr = txt_UserEmail.Text;
                string pwd = txt_Password.Text;

                Session["SDAdmin"] = null;

                if (ValidateUser(usr, pwd) == true)
                {
                    Response.Cookies["SDUser"].Value = usr;
                    Response.Cookies["SDPass"].Value = pwd;
                    Response.Redirect("dashboard.aspx");
                }

                else
                {
                    string msg = "Invalid Login";
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "BQW", "javascript:InfoPopup('','" + msg + "','1');", true);
                    txt_Password.Attributes.Add("value", "********");
                }
            }
            else
            {
                string msg = "Please enter valid data";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "BQW", "javascript:InfoPopup('','" + msg + "','1');", true);
                txt_Password.Attributes.Add("value", "********");
            }

        }

    }
}